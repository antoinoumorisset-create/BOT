import discord
from discord import app_commands
import os
import json
import random
import time
import re
import asyncio
import subprocess
import urllib.request
import urllib.parse
from dotenv import load_dotenv
from openai import OpenAI

# =========================
# CONFIGURATION
# =========================

load_dotenv()

intents = discord.Intents.default()
intents.message_content = True

client = discord.Client(intents=intents)
tree = app_commands.CommandTree(client)

# =========================
# ⚙️ CONFIGURATION DU SERVEUR
# =========================

FICHIER_CONFIG = "config.json"

CONFIG_DEFAUT = {
    "anti_spam": True,
    "anti_emoji": False,
    "anti_mentions": True,
    "xp": True,
    "argent": True,
    "rappels": True,
    "youtube": True,
    "verification": True,
    "musique": True,
}

if os.path.exists(FICHIER_CONFIG):
    try:
        with open(FICHIER_CONFIG, "r", encoding="utf-8") as fichier:
            configurations = json.load(fichier)
    except (json.JSONDecodeError, OSError):
        configurations = {}
else:
    configurations = {}


def sauvegarder_config():
    with open(FICHIER_CONFIG, "w", encoding="utf-8") as fichier:
        json.dump(configurations, fichier, indent=4, ensure_ascii=False)


def config_serveur(guild_id):
    cle = str(guild_id)
    if cle not in configurations:
        configurations[cle] = CONFIG_DEFAUT.copy()
        sauvegarder_config()
    else:
        modifie = False
        for nom, valeur in CONFIG_DEFAUT.items():
            if nom not in configurations[cle]:
                configurations[cle][nom] = valeur
                modifie = True
        if modifie:
            sauvegarder_config()
    return configurations[cle]


def systeme_actif(guild, nom):
    if guild is None:
        return True
    return config_serveur(guild.id).get(nom, CONFIG_DEFAUT.get(nom, True))


# =========================
# SYSTÈME DE RAPPELS
# =========================

rappels = []

async def boucle_rappels():
    await client.wait_until_ready()

    while not client.is_closed():
        await asyncio.sleep(60)

        for rappel in list(rappels):
            try:
                if not systeme_actif(rappel["salon"].guild, "rappels"):
                    continue
                await rappel["salon"].send(f"🔔 **Rappel :** {rappel['texte']}")
            except discord.Forbidden:
                pass
            except discord.HTTPException:
                pass


# =========================
# SYSTÈME YOUTUBE
# =========================

FICHIER_YOUTUBE = "youtube.json"

if os.path.exists(FICHIER_YOUTUBE):
    try:
        with open(FICHIER_YOUTUBE, "r", encoding="utf-8") as fichier:
            youtube_abonnements = json.load(fichier)
    except (json.JSONDecodeError, OSError):
        youtube_abonnements = []
else:
    youtube_abonnements = []


def sauvegarder_youtube():
    with open(FICHIER_YOUTUBE, "w", encoding="utf-8") as fichier:
        json.dump(youtube_abonnements, fichier, indent=4, ensure_ascii=False)


def recuperer_channel_id(url):
    """Récupère l'identifiant d'une chaîne YouTube depuis son URL."""
    url = url.strip()

    # URL directe : https://www.youtube.com/channel/UC...
    match = re.search(r"youtube\.com/channel/([A-Za-z0-9_-]+)", url)
    if match:
        return match.group(1)

    # Pour les URL @handle, /c/ ou /user/, on récupère la page et son channelId.
    if not url.startswith(("http://", "https://")):
        url = "https://" + url

    if "youtube.com/" not in url and "youtu.be/" not in url:
        return None

    try:
        requete = urllib.request.Request(
            url,
            headers={"User-Agent": "Mozilla/5.0"}
        )

        with urllib.request.urlopen(requete, timeout=15) as reponse:
            html = reponse.read().decode("utf-8", errors="ignore")

        # YouTube place généralement le channelId dans les données de la page.
        motifs = [
            r'"channelId":"(UC[A-Za-z0-9_-]+)"',
            r'"externalId":"(UC[A-Za-z0-9_-]+)"',
            r'<meta itemprop="channelId" content="(UC[A-Za-z0-9_-]+)"'
        ]

        for motif in motifs:
            match = re.search(motif, html)
            if match:
                return match.group(1)

    except Exception:
        return None

    return None


def recuperer_derniere_video(channel_id):
    """Récupère la dernière vidéo publiée via le flux RSS officiel de YouTube."""
    rss_url = (
        "https://www.youtube.com/feeds/videos.xml?"
        + urllib.parse.urlencode({"channel_id": channel_id})
    )

    try:
        requete = urllib.request.Request(
            rss_url,
            headers={"User-Agent": "Mozilla/5.0"}
        )

        with urllib.request.urlopen(requete, timeout=15) as reponse:
            xml = reponse.read().decode("utf-8", errors="ignore")

        # Le premier <entry> du flux est la vidéo la plus récente.
        bloc = re.search(r"<entry>(.*?)</entry>", xml, re.DOTALL)
        if not bloc:
            return None

        contenu = bloc.group(1)

        video_id = re.search(r"<yt:videoId>(.*?)</yt:videoId>", contenu)
        titre = re.search(r"<media:title>(.*?)</media:title>", contenu)
        lien = re.search(r'<link rel="alternate" href="([^"]+)"', contenu)

        if not video_id:
            return None

        return {
            "id": video_id.group(1),
            "titre": titre.group(1) if titre else "Nouvelle vidéo",
            "url": lien.group(1) if lien else f"https://www.youtube.com/watch?v={video_id.group(1)}"
        }

    except Exception:
        return None


async def verifier_youtube():
    await client.wait_until_ready()

    while not client.is_closed():
        for abonnement in list(youtube_abonnements):
            try:
                salon = client.get_channel(abonnement.get("salon_id"))
                if salon is not None and not systeme_actif(salon.guild, "youtube"):
                    continue

                derniere = await asyncio.to_thread(
                    recuperer_derniere_video,
                    abonnement["channel_id"]
                )

                if not derniere:
                    continue

                # Au premier contrôle, on mémorise la vidéo actuelle
                # pour éviter d'envoyer toutes les anciennes vidéos.
                if not abonnement.get("derniere_video"):
                    abonnement["derniere_video"] = derniere["id"]
                    sauvegarder_youtube()
                    continue

                if abonnement["derniere_video"] != derniere["id"]:
                    abonnement["derniere_video"] = derniere["id"]
                    sauvegarder_youtube()

                    salon = client.get_channel(abonnement["salon_id"])

                    if salon is not None:
                        await salon.send(
                            f"📺 **Nouvelle vidéo YouTube !**\n"
                            f"🎬 **{derniere['titre']}**\n"
                            f"🔗 {derniere['url']}"
                        )

            except (discord.Forbidden, discord.NotFound, discord.HTTPException):
                pass
            except Exception:
                pass

        # Vérification toutes les 2 minutes.
        await asyncio.sleep(120)



# =========================
# 🎵 SYSTÈME MUSIQUE
# =========================

# Nécessite :
#   pip install yt-dlp PyNaCl
# Et FFmpeg installé et accessible dans le PATH.

attentes_musique = {}
lecteurs_musique = {}


def youtube_audio_url(url):
    """Récupère l'URL audio directe depuis YouTube avec yt-dlp."""
    try:
        import yt_dlp
    except ImportError:
        return None, "❌ Le module `yt-dlp` n'est pas installé. Fais : `pip install yt-dlp`"

    options = {
        "format": "bestaudio/best",
        "quiet": True,
        "no_warnings": True,
        "noplaylist": True,
    }

    try:
        with yt_dlp.YoutubeDL(options) as ydl:
            info = ydl.extract_info(url, download=False)
            if not info:
                return None, "❌ Impossible de trouver cette vidéo YouTube."

            audio_url = info.get("url")
            titre = info.get("title", "Musique inconnue")

            if not audio_url:
                return None, "❌ Impossible de récupérer l'audio de cette vidéo."

            return (audio_url, titre), None

    except Exception as erreur:
        return None, f"❌ Impossible de lire cette vidéo YouTube.\n`{erreur}`"


async def arreter_musique(guild_id):
    lecteur = lecteurs_musique.get(guild_id)

    if lecteur:
        try:
            lecteur.stop()
        except Exception:
            pass

    lecteurs_musique.pop(guild_id, None)


async def jouer_musique(message, url):
    guild = message.guild

    if guild is None:
        await message.channel.send("❌ Cette commande doit être utilisée sur un serveur.")
        return

    if message.author.voice is None or message.author.voice.channel is None:
        await message.channel.send(
            "❌ Tu dois être dans un salon vocal pour utiliser `!joines`."
        )
        return

    vocal = message.author.voice.channel

    try:
        # Connexion au salon vocal
        if guild.voice_client is None:
            voice = await vocal.connect()
        elif guild.voice_client.channel != vocal:
            await guild.voice_client.move_to(vocal)
            voice = guild.voice_client
        else:
            voice = guild.voice_client

        await message.channel.send("🔎 **Recherche de la musique...**")

        resultat, erreur = await asyncio.to_thread(youtube_audio_url, url)

        if erreur:
            await message.channel.send(erreur)
            return

        audio_url, titre = resultat

        await arreter_musique(guild.id)

        ffmpeg_options = {
            "before_options": "-reconnect 1 -reconnect_streamed 1 -reconnect_delay_max 5",
            "options": "-vn",
        }

        source = discord.FFmpegPCMAudio(
            audio_url,
            executable="ffmpeg",
            **ffmpeg_options
        )

        def musique_terminee(erreur_fin):
            if erreur_fin:
                print(f"Erreur lecture musique : {erreur_fin}")

        lecteurs_musique[guild.id] = source
        voice.play(source, after=musique_terminee)

        await message.channel.send(
            f"🎵 **Lecture en cours !**\n"
            f"🎶 **{titre}**\n"
            f"🔗 {url}"
        )

    except discord.ClientException as erreur:
        await message.channel.send(
            f"❌ Impossible de rejoindre/lire la musique : `{erreur}`"
        )
    except Exception as erreur:
        await message.channel.send(
            f"❌ Erreur pendant la lecture : `{erreur}`"
        )


# =========================
# 💰 SYSTÈME D'ARGENT
# =========================

FICHIER_ARGENT = "argent.json"

if os.path.exists(FICHIER_ARGENT):
    try:
        with open(FICHIER_ARGENT, "r", encoding="utf-8") as fichier:
            argent = json.load(fichier)
    except (json.JSONDecodeError, OSError):
        argent = {}
else:
    argent = {}

dernier_argent = {}


def sauvegarder_argent():
    with open(FICHIER_ARGENT, "w", encoding="utf-8") as fichier:
        json.dump(argent, fichier, indent=4, ensure_ascii=False)


def donner_argent(utilisateur, montant):
    utilisateur = str(utilisateur)
    argent[utilisateur] = argent.get(utilisateur, 0) + montant
    sauvegarder_argent()


def solde_utilisateur(utilisateur):
    return argent.get(str(utilisateur), 0)


# =========================
# 🛒 BOUTIQUE
# =========================

FICHIER_BOUTIQUE = "boutique.json"

if os.path.exists(FICHIER_BOUTIQUE):
    try:
        with open(FICHIER_BOUTIQUE, "r", encoding="utf-8") as fichier:
            boutique = json.load(fichier)
    except (json.JSONDecodeError, OSError):
        boutique = []
else:
    boutique = []


def sauvegarder_boutique():
    with open(FICHIER_BOUTIQUE, "w", encoding="utf-8") as fichier:
        json.dump(boutique, fichier, indent=4, ensure_ascii=False)


def prochain_id_article():
    if not boutique:
        return 1
    return max(int(article.get("id", 0)) for article in boutique) + 1


FICHIER_NIVEAUX = "levels.json"


# =========================
# SYSTÈME DE NIVEAUX
# =========================

if os.path.exists(FICHIER_NIVEAUX):
    with open(FICHIER_NIVEAUX, "r", encoding="utf-8") as fichier:
        niveaux = json.load(fichier)
else:
    niveaux = {}


def sauvegarder_niveaux():
    with open(FICHIER_NIVEAUX, "w", encoding="utf-8") as fichier:
        json.dump(niveaux, fichier, indent=4)


def xp_pour_niveau(niveau):
    # Courbe très progressive : plus le niveau monte, plus il faut
    # d'XP. Cela évite que les hauts niveaux défilent trop vite.
    if niveau <= 1:
        return 100
    return int(100 * (niveau ** 1.55))


def barre_xp(xp, xp_necessaire, longueur=16):
    progression = min(xp / max(xp_necessaire, 1), 1)
    remplis = int(progression * longueur)
    return "🟩" * remplis + "⬜" * (longueur - remplis)


# XP dynamique : activité, longueur, série de messages et hasard.
# Les données restent en mémoire uniquement pendant l'exécution du bot.
dernier_xp = {}
series_xp = {}


def calculer_xp(utilisateur, contenu):
    maintenant = time.time()
    dernier = dernier_xp.get(utilisateur, 0)

    # Petit cooldown pour éviter de gagner de l'XP en envoyant 30 messages
    # à la suite. Les humains ont découvert le spam avant les robots, évidemment.
    if maintenant - dernier < 8:
        return 0

    dernier_xp[utilisateur] = maintenant

    # Série d'activité : rester actif régulièrement donne un bonus.
    if maintenant - dernier_xp.get(f"serie_{utilisateur}", 0) < 120:
        series_xp[utilisateur] = min(series_xp.get(utilisateur, 0) + 1, 10)
    else:
        series_xp[utilisateur] = 1
    dernier_xp[f"serie_{utilisateur}"] = maintenant

    xp = random.randint(8, 20)
    xp += min(len(contenu) // 50, 8)
    xp += series_xp[utilisateur] // 3

    # Rare bonus, sans rendre le système complètement absurde.
    if random.random() < 0.08:
        xp *= 2

    return xp
    remplis = int(progression * longueur)
    return "🟩" * remplis + "⬜" * (longueur - remplis)


# =========================
# ANTI-SPAM
# =========================

messages_recents = {}

MAX_MESSAGES = 5
TEMPS_MAX = 30

dernier_avertissement = {}


def verifier_spam(utilisateur):
    maintenant = time.time()

    if utilisateur not in messages_recents:
        messages_recents[utilisateur] = []

    messages_recents[utilisateur] = [
        temps
        for temps in messages_recents[utilisateur]
        if maintenant - temps < TEMPS_MAX
    ]

    messages_recents[utilisateur].append(maintenant)

    return len(messages_recents[utilisateur]) > MAX_MESSAGES


# =========================
# DÉTECTION DES EMOJIS
# =========================

emoji_discord_pattern = re.compile(r"<a?:\w+:\d+>")

emoji_unicode_pattern = re.compile(
    "["
    "\U0001F1E0-\U0001F1FF"
    "\U0001F300-\U0001F5FF"
    "\U0001F600-\U0001F64F"
    "\U0001F680-\U0001F6FF"
    "\U0001F700-\U0001F77F"
    "\U0001F780-\U0001F7FF"
    "\U0001F800-\U0001F8FF"
    "\U0001F900-\U0001F9FF"
    "\U0001FA00-\U0001FA6F"
    "\U0001FA70-\U0001FAFF"
    "\u2300-\u23FF"
    "\u2600-\u26FF"
    "\u2700-\u27BF"
    "\u2B00-\u2BFF"
    "\u3030"
    "\u303D"
    "\u3297"
    "\u3299"
    "]+",
    flags=re.UNICODE
)


def contient_emoji(texte):

    # Emojis Discord personnalisés
    if emoji_discord_pattern.search(texte):
        return True

    # Emojis Unicode
    if emoji_unicode_pattern.search(texte):
        return True

    # Éléments utilisés par certains emojis
    caracteres_emoji = [
        "\u200d",  # Zero Width Joiner
        "\ufe0f",  # Variation Selector
        "\u20e3"   # Keycap
    ]

    for caractere in caracteres_emoji:
        if caractere in texte:
            return True

    return False


# =========================
# FONCTION POUR RÉPONDRE
# =========================

async def repondre(message, texte):

    try:
        await message.delete()
    except discord.Forbidden:
        pass
    except discord.NotFound:
        pass

    await message.channel.send(texte)


# =========================
# RAPPEL VÉRIFICATION DU SERVEUR
# =========================

async def rappel_verification():
    await client.wait_until_ready()

    while not client.is_closed():
        for guild in client.guilds:
            if not systeme_actif(guild, "verification"):
                continue
            salon = discord.utils.get(
                guild.text_channels,
                name="🫥・𝗺𝗼𝗱𝗲𝗿𝗮𝘁𝗶𝗼𝗻"
            )

            if salon is not None:
                try:
                    await salon.send("🔎 **Vérifiez le serveur !**")
                except discord.Forbidden:
                    pass
                except discord.HTTPException:
                    pass

        await asyncio.sleep(300)  # 5 minutes


# =========================
# BOT CONNECTÉ
# =========================

@client.event
async def on_ready():

    print("-----------------------------------")
    print(f"Bot connecté en tant que {client.user}")
    print("-----------------------------------")

    if not getattr(client, "slash_sync_fait", False):
        try:
            await tree.sync()
            client.slash_sync_fait = True
            print("Commandes slash synchronisées !")
        except Exception as erreur:
            print(f"Erreur synchronisation slash : {erreur}")

    if not hasattr(client, "rappel_verification_lance"):
        client.rappel_verification_lance = True
        asyncio.create_task(rappel_verification())

    if not hasattr(client, "boucle_rappels_lancee"):
        client.boucle_rappels_lancee = True
        asyncio.create_task(boucle_rappels())


    if not hasattr(client, "verif_youtube_lancee"):
        client.verif_youtube_lancee = True
        asyncio.create_task(verifier_youtube())


# =========================
# RÉCEPTION DES MESSAGES
# =========================

@client.event
async def on_message(message):

    # Ignore le bot lui-même
    if message.author == client.user:
        return

    utilisateur = str(message.author.id)

    # =========================
    # 🚫 BLOQUER LES MENTIONS @everyone / @here
    # =========================

    if systeme_actif(message.guild, "anti_mentions") and message.mention_everyone:
        try:
            await message.delete()
        except discord.Forbidden:
            pass
        except discord.NotFound:
            pass

        await message.channel.send(
            f"🚫 {message.author.mention}, les mentions `@everyone` et `@here` sont interdites !"
        )
        return

    # =========================
    # 📣 MENTION DU BOT
    # =========================

    if client.user in message.mentions:
        salon_support = discord.utils.get(
            message.guild.text_channels if message.guild else [],
            name="🤓・bot-suport"
        )

        if salon_support is not None:
            await salon_support.send(
                f"📣 {message.author.mention} a mentionné le bot ! 🤖"
            )
        return

    # =========================
    # ANTI-SPAM
    # =========================

    if systeme_actif(message.guild, "anti_spam") and verifier_spam(utilisateur):

        maintenant = time.time()

        if (
            utilisateur not in dernier_avertissement
            or maintenant - dernier_avertissement[utilisateur] >= 10
        ):

            dernier_avertissement[utilisateur] = maintenant

            try:
                await message.delete()
            except discord.Forbidden:
                pass
            except discord.NotFound:
                pass

            await message.channel.send(
                f"⚠️ {message.author.mention}, **attention au spam !**\n"
                f"Tu as envoyé plus de **{MAX_MESSAGES} messages "
                f"en {TEMPS_MAX} secondes**."
            )

        else:

            try:
                await message.delete()
            except discord.Forbidden:
                pass
            except discord.NotFound:
                pass

        return

    # =========================
    # 🚫 ANTI-EMOJI AUTOMATIQUE
    # =========================

    if systeme_actif(message.guild, "anti_emoji") and contient_emoji(message.content):
        try:
            await message.delete()
        except (discord.Forbidden, discord.NotFound):
            pass
        return

    # =========================
    # 💰 ARGENT
    # =========================

    maintenant = time.time()
    dernier = dernier_argent.get(utilisateur, 0)

    if systeme_actif(message.guild, "argent") and maintenant - dernier >= 8:
        dernier_argent[utilisateur] = maintenant
        gain_argent = random.randint(5, 15)
        gain_argent += min(len(message.content) // 100, 5)
        donner_argent(utilisateur, gain_argent)

    # =========================
    # XP
    # =========================

    if not systeme_actif(message.guild, "xp"):
        xp_gagne = 0
    else:
        xp_gagne = calculer_xp(utilisateur, message.content)

    if utilisateur not in niveaux:

        niveaux[utilisateur] = {
            "xp": 0,
            "niveau": 1
        }

    if xp_gagne <= 0:
        return

    niveaux[utilisateur]["xp"] += xp_gagne
    niveaux[utilisateur]["niveau"] = max(1, niveaux[utilisateur].get("niveau", 1))

    niveaux_gagnes = []

    # Permet de franchir plusieurs niveaux si beaucoup d'XP est ajoutée d'un coup.
    while niveaux[utilisateur]["xp"] >= xp_pour_niveau(niveaux[utilisateur]["niveau"]):
        xp_necessaire = xp_pour_niveau(niveaux[utilisateur]["niveau"])
        niveaux[utilisateur]["xp"] -= xp_necessaire
        niveaux[utilisateur]["niveau"] += 1
        niveaux_gagnes.append(niveaux[utilisateur]["niveau"])

    sauvegarder_niveaux()

    if niveaux_gagnes:
        nouveau_niveau = niveaux[utilisateur]["niveau"]
        await message.channel.send(
            f"🎉 **Félicitations {message.author.mention} !**\n"
            f"⭐ Tu viens de passer au **niveau {nouveau_niveau}** !\n"
            f"✨ XP gagnée : **+{xp_gagne}**"
        )

    # =========================
    # COMMANDE
    # =========================

    contenu_original = message.content
    contenu = message.content.strip()

    commande = contenu.lower()


    # =========================
    # !MESSAGE
    # =========================

    if commande.startswith("!message "):

        texte = contenu[9:].strip()

        if texte:

            try:
                await message.delete()
            except discord.Forbidden:
                pass
            except discord.NotFound:
                pass

            await message.channel.send(texte)

        return


    # =========================
    # !AIDE
    # =========================

    if commande == "!aide":

        texte = """
📚 **COMMANDES DU BOT**

🏓 `!ping`
👋 `!bonjour`
😎 `!salut`
❤️ `!merci`
🥳 `!bravo`
🎉 `!gg`
😂 `!lol`
😂 `!mdr`
😂 `!haha`
☀️ `!bonnejournee`
🌙 `!bonnenuit`
💪 `!courage`
🔥 `!motivation`
😂 `!blague`
🐱 `!chat`
🐶 `!chien`
⛏️ `!minecraft`
🎮 `!gaming`
❤️ `!coeur`
😢 `!triste`
👑 `!roi`
⭐ `!etoile`
🎉 `!bienvenue`
🫡 `!respect`
😎 `!classe`
💀 `!wtf`
😮‍💨 `!ouf`
🍕 `!bonappetit`
🍀 `!bonnechance`
🐮 `!vache`
🐷 `!cochon`
🐑 `!mouton`
🐔 `!poule`
💚 `!creeper`
💎 `!diamant`
😂 `!noob`
😎 `!cool`

📨 `!message <texte>`
⭐ `!niveaux`
🚫 `!noemoji`
🧹 `!resetmessages`
🔔 `!rapelle <message>`
🛑 `!resetrapelles`
📺 `!youtube <url_chaine>`
🛑 `!resetyoutube`
🎵 `!joines` → jouer une musique YouTube dans ton salon vocal
⏹️ `!stop` → arrêter la musique et quitter le vocal
✅ `!confirmerreset`
🎭 `!troll`
🤖 `!chatgpt` → poser une question à ChatGPT
🌐 `!web` → rechercher quelque chose sur le web
🆘 `!urgence` → mentionner un membre et appliquer une sanction
💘 `!amourre @membre1 @membre2` → faux calculateur d'amour
🧠 `!debille @membre1 @membre2` → faux calculateur de débilité
"""

        await repondre(message, texte)
        return


    # =========================
    # !NIVEAUX
    # =========================

    if commande == "!niveaux":

        niveau = niveaux[utilisateur]["niveau"]
        xp = niveaux[utilisateur]["xp"]
        xp_necessaire = xp_pour_niveau(niveau)

        await repondre(
            message,
            f"⭐ **Tes niveaux**\n\n"
            f"🏆 Niveau : **{niveau}**\n"
            f"✨ XP : **{xp}/{xp_necessaire}**"
        )

        return


    # =========================
    # !NOEMOJI
    # =========================

    if commande == "!noemoji":

        try:
            await message.delete()
        except discord.Forbidden:
            pass
        except discord.NotFound:
            pass

        message_info = await message.channel.send(
            "🚫 **Nettoyage des emojis en cours...**"
        )

        supprimes = 0

        try:

            async for msg in message.channel.history(limit=None):

                if msg.author == client.user:
                    continue

                if contient_emoji(msg.content):

                    try:
                        await msg.delete()
                        supprimes += 1
                    except discord.Forbidden:
                        pass
                    except discord.NotFound:
                        pass

        except discord.Forbidden:

            await message_info.edit(
                content="❌ Je n'ai pas la permission de gérer les messages."
            )
            return

        try:
            await message_info.delete()
        except:
            pass

        await message.channel.send(
            f"🚫 **Nettoyage terminé !**\n"
            f"🧹 **{supprimes} message(s)** contenant un emoji supprimé(s)."
        )

        return


    # =========================
    # !RAPELLE
    # =========================

    if commande.startswith("!rapelle "):

        texte_rappel = contenu[len("!rapelle "):].strip()

        if not texte_rappel:
            await repondre(message, "❌ Utilisation : `!rapelle <message>`")
            return

        try:
            await message.delete()
        except discord.Forbidden:
            pass
        except discord.NotFound:
            pass

        salon_discussions = discord.utils.get(
            message.guild.text_channels,
            name="💬・𝗱𝗶𝘀𝗰𝘂𝘀𝘀𝗶𝗼𝗻𝘀"
        )

        if salon_discussions is None:
            await message.channel.send(
                "❌ Le salon `💬・𝗱𝗶𝘀𝗰𝘂𝘀𝘀𝗶𝗼𝗻𝘀` est introuvable."
            )
            return

        rappels.append({
            "texte": texte_rappel,
            "salon": salon_discussions,
            "auteur": message.author.id
        })

        await message.channel.send(
            f"🔔 **Rappel activé !**\n"
            f"📢 Message : **{texte_rappel}**\n"
            f"⏱️ Envoi toutes les **1 minute** dans {salon_discussions.mention}."
        )
        return


    # =========================
    # !RESETRAPELLES
    # =========================

    if commande == "!resetrapelles":

        if not message.author.guild_permissions.administrator:
            await repondre(
                message,
                "❌ Cette commande est réservée aux administrateurs."
            )
            return

        try:
            await message.delete()
        except discord.Forbidden:
            pass
        except discord.NotFound:
            pass

        nombre = len(rappels)
        rappels.clear()

        await message.channel.send(
            f"🛑 **Rappels désactivés !**\n"
            f"🗑️ **{nombre} rappel(s)** supprimé(s)."
        )
        return


    # =========================
    # !YOUTUBE
    # =========================

    if commande.startswith("!youtube "):

        url_chaine = contenu[len("!youtube "):].strip()

        if not url_chaine:
            await repondre(
                message,
                "❌ Utilisation : `!youtube <URL de la chaîne>`"
            )
            return

        try:
            await message.delete()
        except discord.Forbidden:
            pass
        except discord.NotFound:
            pass

        channel_id = await asyncio.to_thread(
            recuperer_channel_id,
            url_chaine
        )

        if not channel_id:
            await message.channel.send(
                "❌ Je n'arrive pas à trouver l'identifiant de cette chaîne YouTube.\n"
                "💡 Utilise de préférence une URL du type "
                "`https://www.youtube.com/@NomDeLaChaine` ou "
                "`https://www.youtube.com/channel/UC...`."
            )
            return

        # Évite de créer deux abonnements identiques dans le même salon.
        deja_abonne = any(
            a["channel_id"] == channel_id
            and a["salon_id"] == message.channel.id
            for a in youtube_abonnements
        )

        if deja_abonne:
            await message.channel.send(
                "⚠️ Cette chaîne YouTube est déjà surveillée dans ce salon."
            )
            return

        derniere = await asyncio.to_thread(
            recuperer_derniere_video,
            channel_id
        )

        youtube_abonnements.append({
            "channel_id": channel_id,
            "salon_id": message.channel.id,
            "derniere_video": derniere["id"] if derniere else None
        })
        sauvegarder_youtube()

        await message.channel.send(
            "📺 **Chaîne YouTube ajoutée !**\n"
            f"🔗 {url_chaine}\n"
            "📢 Dès qu'une nouvelle vidéo sortira, elle sera envoyée ici automatiquement.\n"
            "⏱️ Vérification environ toutes les **2 minutes**."
        )
        return


    # =========================
    # !RESETYOUTUBE
    # =========================

    if commande == "!resetyoutube":

        if not message.author.guild_permissions.administrator:
            await repondre(
                message,
                "❌ Cette commande est réservée aux administrateurs."
            )
            return

        try:
            await message.delete()
        except discord.Forbidden:
            pass
        except discord.NotFound:
            pass

        # Retire uniquement les abonnements du salon où la commande est utilisée.
        avant = len(youtube_abonnements)
        youtube_abonnements[:] = [
            a for a in youtube_abonnements
            if a["salon_id"] != message.channel.id
        ]
        supprimes = avant - len(youtube_abonnements)
        sauvegarder_youtube()

        await message.channel.send(
            f"🛑 **Notifications YouTube désactivées !**\n"
            f"🗑️ **{supprimes} abonnement(s)** retiré(s) de ce salon."
        )
        return



    # =========================
    # !CHATGPT
    # =========================

    if commande == "!chatgpt":

        try:
            await message.delete()
        except discord.Forbidden:
            pass
        except discord.NotFound:
            pass

        if not os.getenv("OPENAI_API_KEY"):
            await message.channel.send(
                "❌ **ChatGPT n'est pas configuré.**\n"
                "Ajoute ta clé dans `.env` avec : `OPENAI_API_KEY=...` puis redémarre le bot.\n"
                "🔐 **Ne m'envoie jamais ta clé API sur Discord.**"
            )
            return

        attentes_chatgpt.add(message.author.id)
        await message.channel.send(
            f"🤖 {message.author.mention} **Mode ChatGPT activé !**\n"
            "💬 Envoie maintenant ta question ou ton message."
        )
        return


    # =========================
    # MESSAGE POUR !CHATGPT
    # =========================

    if message.author.id in attentes_chatgpt:

        attentes_chatgpt.discard(message.author.id)

        texte_chatgpt = contenu.strip()

        if not texte_chatgpt:
            await repondre(message, "❌ Ton message est vide.")
            return

        try:
            await message.delete()
        except discord.Forbidden:
            pass
        except discord.NotFound:
            pass

        message_attente = await message.channel.send("🤖 **ChatGPT réfléchit...**")

        reponse, erreur = await asyncio.to_thread(
            demander_chatgpt,
            texte_chatgpt
        )

        if erreur:
            try:
                await message_attente.edit(content=erreur)
            except discord.HTTPException:
                pass
            return

        # Discord limite les messages à 2000 caractères.
        morceaux = [
            reponse[i:i + 1900]
            for i in range(0, len(reponse), 1900)
        ] or ["(Réponse vide)"]

        try:
            await message_attente.edit(content=f"🤖 **ChatGPT :**\n{morceaux[0]}")
        except discord.HTTPException:
            pass

        for morceau in morceaux[1:]:
            await message.channel.send(morceau)

        return



    # =========================
    # !URGENCE
    # =========================

    if commande == "!urgence":
        if message.guild is None:
            await repondre(message, "❌ Cette commande doit être utilisée sur un serveur.")
            return

        try:
            await message.delete()
        except discord.Forbidden:
            pass
        except discord.NotFound:
            pass

        attentes_urgence[message.author.id] = {
            "guild_id": message.guild.id,
            "channel_id": message.channel.id
        }

        await message.channel.send(
            f"🚨 {message.author.mention} **Mode urgence activé !**\n"
            "👤 Mentionne maintenant le membre concerné, puis écris le motif."
        )
        return


    # =========================
    # MENTION POUR !URGENCE
    # =========================

    urgence = attentes_urgence.get(message.author.id)

    if urgence:
        if (
            message.guild is not None
            and urgence["guild_id"] == message.guild.id
            and urgence["channel_id"] == message.channel.id
        ):
            membres_mentionnes = message.mentions

            if not membres_mentionnes:
                await repondre(
                    message,
                    "❌ Tu dois mentionner le membre à sanctionner."
                )
                return

            membre = membres_mentionnes[0]
            motif = re.sub(r"<@!?\d+>", "", contenu).strip()

            if not motif:
                await repondre(
                    message,
                    "❌ Écris aussi le motif après la mention."
                )
                return

            attentes_urgence.pop(message.author.id, None)

            try:
                await message.delete()
            except discord.Forbidden:
                pass
            except discord.NotFound:
                pass

            # Sanction : timeout de 10 minutes.
            try:
                import datetime
                await membre.timeout(
                    datetime.timedelta(minutes=10),
                    reason=f"Urgence : {motif}"
                )
                sanction = "⛔ Sanction appliquée : **timeout de 10 minutes**."
            except discord.Forbidden:
                sanction = "⚠️ Je n'ai pas la permission d'appliquer la sanction à ce membre."
            except discord.HTTPException:
                sanction = "⚠️ Impossible d'appliquer la sanction."

            await message.channel.send(
                f"🚨 **URGENCE**\n"
                f"👤 Membre : {membre.mention}\n"
                f"{sanction}\n"
                f"📝 **Motif :** {motif}"
            )
            return


    # =========================
    # !AMOURRE
    # =========================

    if commande == "!amourre":
        membres_mentionnes = message.mentions

        if len(membres_mentionnes) != 2:
            await repondre(
                message,
                "❌ Utilisation : `!amourre @membre1 @membre2`"
            )
            return

        personne1 = membres_mentionnes[0]
        personne2 = membres_mentionnes[1]

        # Pourcentage totalement aléatoire à chaque utilisation.
        pourcentage = random.randint(0, 100)

        if pourcentage < 20:
            phrase = "💔 Ça sent mal..."
        elif pourcentage < 40:
            phrase = "😬 Il y a peut-être un petit quelque chose..."
        elif pourcentage < 60:
            phrase = "👀 C'est mitigé..."
        elif pourcentage < 80:
            phrase = "💕 Ça commence à devenir sérieux !"
        elif pourcentage < 95:
            phrase = "💖 Très belle compatibilité !"
        else:
            phrase = "💘 L'AMOUR ABSOLU !"

        await repondre(
            message,
            f"💘 **CALCULATEUR D'AMOUR** 💘\n\n"
            f"👤 {personne1.mention} ❤️ {personne2.mention}\n\n"
            f"💞 Compatibilité : **{pourcentage}%**\n"
            f"{phrase}"
        )
        return


    # =========================
    # !DEBILLE
    # =========================

    if commande == "!debille":
        membres_mentionnes = message.mentions

        if len(membres_mentionnes) != 2:
            await repondre(message, "❌ Utilisation : `!debille @membre1 @membre2`")
            return

        personne1 = membres_mentionnes[0]
        personne2 = membres_mentionnes[1]

        pourcentage1 = random.randint(0, 100)
        pourcentage2 = random.randint(0, 100)

        def phrase_debile(pourcentage):
            if pourcentage < 20:
                return "🧠 Intelligence en vacances..."
            elif pourcentage < 40:
                return "😅 Quelques neurones fonctionnent encore."
            elif pourcentage < 60:
                return "🤔 Niveau de débilité modéré."
            elif pourcentage < 80:
                return "😂 Ça commence à devenir inquiétant."
            elif pourcentage < 95:
                return "🤪 Niveau de débilité élevé !"
            return "💀 LE CERVEAU A QUITTÉ LE SERVEUR !"

        await repondre(
            message,
            f"🧠 **CALCULATEUR DE DÉBILITÉ** 🧠\n\n"
            f"👤 {personne1.mention} : **{pourcentage1}%**\n"
            f"{phrase_debile(pourcentage1)}\n\n"
            f"👤 {personne2.mention} : **{pourcentage2}%**\n"
            f"{phrase_debile(pourcentage2)}"
        )
        return


    # =========================
    # !WEB
    # =========================

    if commande == "!web":

        try:
            await message.delete()
        except discord.Forbidden:
            pass
        except discord.NotFound:
            pass

        attentes_web.add(message.author.id)

        await message.channel.send(
            f"🌐 {message.author.mention} **Mode recherche web activé !**\n"
            "🔎 Envoie maintenant ce que tu veux rechercher."
        )
        return


    # =========================
    # MESSAGE POUR !WEB
    # =========================

    if message.author.id in attentes_web:

        attentes_web.discard(message.author.id)

        recherche = contenu.strip()

        if not recherche:
            await repondre(message, "❌ Ta recherche est vide.")
            return

        try:
            await message.delete()
        except discord.Forbidden:
            pass
        except discord.NotFound:
            pass

        message_attente = await message.channel.send(
            "🌐 **Recherche sur le web en cours...** 🔎"
        )

        resultat, erreur = await asyncio.to_thread(
            rechercher_web,
            recherche
        )

        if erreur:
            try:
                await message_attente.edit(content=erreur)
            except discord.HTTPException:
                pass
            return

        morceaux = [
            resultat[i:i + 1900]
            for i in range(0, len(resultat), 1900)
        ] or ["Aucun résultat."]

        try:
            await message_attente.edit(
                content=f"🌐 **Résultat de la recherche :**\n{morceaux[0]}"
            )
        except discord.HTTPException:
            pass

        for morceau in morceaux[1:]:
            await message.channel.send(morceau)

        return



    # =========================
    # !JOINES
    # =========================

    if commande == "!joines":

        if message.guild is None:
            await repondre(message, "❌ Cette commande doit être utilisée sur un serveur.")
            return

        if message.author.voice is None or message.author.voice.channel is None:
            await repondre(
                message,
                "❌ Tu dois être dans un salon vocal pour utiliser `!joines`."
            )
            return

        try:
            await message.delete()
        except discord.Forbidden:
            pass
        except discord.NotFound:
            pass

        attentes_musique[message.author.id] = {
            "guild_id": message.guild.id,
            "channel_id": message.channel.id
        }

        await message.channel.send(
            "🎵 **Mode musique activé !**\n"
            "📺 Envoie maintenant **l'URL YouTube de la musique** que tu veux écouter.\n"
            "⏳ J'attends ton lien..."
        )
        return


    # =========================
    # LIEN YOUTUBE POUR !JOINES
    # =========================

    attente = attentes_musique.get(message.author.id)

    if attente:
        if (
            attente["guild_id"] == message.guild.id
            and attente["channel_id"] == message.channel.id
        ):
            url_musique = contenu.strip()

            if not re.match(
                r"^https?://(www\.)?(youtube\.com/watch\?v=|youtu\.be/)",
                url_musique
            ):
                await repondre(
                    message,
                    "❌ Envoie une **URL YouTube valide**.\n"
                    "Exemple : `https://www.youtube.com/watch?v=...`"
                )
                return

            attentes_musique.pop(message.author.id, None)

            try:
                await message.delete()
            except discord.Forbidden:
                pass
            except discord.NotFound:
                pass

            await jouer_musique(message, url_musique)
            return


    # =========================
    # !STOP
    # =========================

    if commande == "!stop":

        if message.guild is None:
            await repondre(message, "❌ Cette commande doit être utilisée sur un serveur.")
            return

        voice = message.guild.voice_client

        if voice is None:
            await repondre(message, "❌ Je ne suis pas dans un salon vocal.")
            return

        if not message.author.voice or message.author.voice.channel != voice.channel:
            await repondre(
                message,
                "❌ Tu dois être dans le même salon vocal que le bot."
            )
            return

        await arreter_musique(message.guild.id)

        try:
            await voice.disconnect()
        except discord.HTTPException:
            pass

        await repondre(message, "⏹️ **Musique arrêtée et bot déconnecté.**")
        return


    # =========================
    # !RESETMESSAGES
    # =========================

    if commande == "!resetmessages":

        if not message.author.guild_permissions.administrator:

            await repondre(
                message,
                "❌ Cette commande est réservée aux administrateurs."
            )

            return

        await repondre(
            message,
            "⚠️ **ATTENTION !**\n\n"
            "Cette commande va supprimer les messages du serveur.\n"
            "Pour confirmer, utilise : `!confirmerreset`"
        )

        return


    # =========================
    # !CONFIRMERRESET
    # =========================

    if commande == "!confirmerreset":

        if not message.author.guild_permissions.administrator:

            await repondre(
                message,
                "❌ Cette commande est réservée aux administrateurs."
            )

            return

        try:
            await message.delete()
        except discord.Forbidden:
            pass
        except discord.NotFound:
            pass

        message_info = await message.channel.send(
            "🧹 **Suppression des messages en cours...**"
        )

        total = 0

        for channel in message.guild.text_channels:

            try:

                async for msg in channel.history(limit=None):

                    try:
                        await msg.delete()
                        total += 1

                        await asyncio.sleep(0.15)

                    except discord.NotFound:
                        pass

                    except discord.Forbidden:
                        break

                    except discord.HTTPException as erreur:

                        if erreur.status == 429:
                            await asyncio.sleep(
                                getattr(erreur, "retry_after", 2)
                            )

            except discord.Forbidden:
                continue

            except discord.HTTPException:
                continue

        try:
            await message_info.edit(
                content=f"🧹 **Nettoyage terminé !**\n"
                        f"🗑️ **{total} message(s)** supprimé(s)."
            )
        except discord.HTTPException:
            pass

        return


    # =========================
    # !TROLL
    # =========================

    if commande == "!troll":

        try:
            await message.delete()
        except discord.Forbidden:
            pass
        except discord.NotFound:
            pass

        msg = await message.channel.send(
            "🎭 **TROLL ACTIVÉ !**"
        )

        messages_troll = [

            "🤖 Initialisation...",

            "⚠️ Analyse du serveur...",

            "👀 Surveillance activée...",

            "📡 Connexion...",

            "❌ Connexion refusée.",

            "🔄 Nouvelle tentative...",

            "🧠 Chargement du cerveau...",

            "🧠 1%...",

            "🧠 2%...",

            "💀 Erreur.",

            "🚨 ALERTE !",

            "🔥 Système instable...",

            "👀 Vous êtes toujours là ?",

            "🗿 Patientez...",

            "😂 Mauvaise décision."

        ]

        for i in range(60):

            texte = messages_troll[i % len(messages_troll)]

            temps_restant = 30 - (i // 2)

            try:

                await msg.edit(
                    content=
                    f"🎭 **TROLL**\n"
                    f"{texte}\n\n"
                    f"⏱️ Encore **{temps_restant}s**..."
                )

            except discord.HTTPException:
                pass

            await asyncio.sleep(0.5)

        try:

            await msg.edit(
                content="💀 **TROLL TERMINÉ !**\n"
                        "Le serveur peut maintenant retrouver sa dignité. 🗿"
            )

        except discord.HTTPException:
            pass

        return


    # =========================
    # PETITES COMMANDES
    # =========================

    commandes_simples = {

        "!ping":
            "Pong ! 🏓",

        "!bonjour":
            "Bonjour ! 👋",

        "!salut":
            "Salut ! 😎",

        "!merci":
            "Avec plaisir ! ❤️",

        "!bravo":
            "Bravo ! 🥳",

        "!gg":
            "GG ! 🎉",

        "!lol":
            "😂😂😂",

        "!mdr":
            "MDR 😂",

        "!haha":
            "HAHA 😂",

        "!bonnejournee":
            "Bonne journée ! ☀️",

        "!bonnenuit":
            "Bonne nuit ! 🌙",

        "!courage":
            "Courage ! 💪",

        "!motivation":
            "On lâche rien ! 🔥",

        "!blague":
            "Pourquoi les plongeurs plongent-ils toujours en arrière ? Parce que sinon ils tombent dans le bateau. 😂",

        "!chat":
            "Miaou ! 🐱",

        "!chien":
            "Wouf ! 🐶",

        "!minecraft":
            "Minecraft ! ⛏️",

        "!gaming":
            "Let's go gaming ! 🎮",

        "!coeur":
            "❤️",

        "!triste":
            "Courage ❤️",

        "!roi":
            "👑 Le roi !",

        "!etoile":
            "⭐",

        "!bienvenue":
            "Bienvenue ! 🎉",

        "!respect":
            "Respect ! 🫡",

        "!classe":
            "La classe ! 😎",

        "!wtf":
            "WTF 💀",

        "!ouf":
            "OUF 😮‍💨",

        "!bonappetit":
            "Bon appétit ! 🍕",

        "!bonnechance":
            "Bonne chance ! 🍀",

        "!vache":
            "Meuh ! 🐮",

        "!cochon":
            "Groin ! 🐷",

        "!mouton":
            "Bêêê ! 🐑",

        "!poule":
            "Cot cot ! 🐔",

        "!creeper":
            "SSSSSSSS... 💚",

        "!diamant":
            "DIAMANT ! 💎",

        "!noob":
            "NOOB 😂",

        "!cool":
            "Trop cool ! 😎"
    }


    if commande in commandes_simples:

        await repondre(
            message,
            commandes_simples[commande]
        )

        return


# =========================
# 🤖 SYSTÈME CHATGPT
# =========================

# ⚠️ La clé OpenAI NE DOIT PAS être envoyée dans Discord.
# Mets-la dans le fichier .env :
# OPENAI_API_KEY=ta_cle_ici
#
# Nécessite :
#   pip install openai

attentes_chatgpt = set()
attentes_web = set()
attentes_urgence = {}


def demander_chatgpt(texte):
    """Envoie une demande à l'API OpenAI et renvoie le texte de réponse."""
    api_key = os.getenv("OPENAI_API_KEY")

    if not api_key:
        return (
            None,
            "❌ La clé OpenAI n'est pas configurée.\n"
            "Ajoute `OPENAI_API_KEY=...` dans ton fichier `.env`, puis redémarre le bot.\n"
            "🔐 Ne mets jamais ta clé API dans un message Discord."
        )

    try:
        client_openai = OpenAI(api_key=api_key)
        reponse = client_openai.responses.create(
            model="gpt-5.6-luna",
            input=texte
        )
        return reponse.output_text, None
    except Exception as erreur:
        return None, f"❌ Erreur avec l'API OpenAI : `{erreur}`"


# =========================
# 🌐 SYSTÈME RECHERCHE WEB
# =========================

def rechercher_web(texte):
    """Recherche sur le web avec l'outil Web Search de l'API OpenAI."""
    api_key = os.getenv("OPENAI_API_KEY")

    if not api_key:
        return (
            None,
            "❌ La clé OpenAI n'est pas configurée.\n"
            "Ajoute `OPENAI_API_KEY=...` dans ton fichier `.env`, puis redémarre le bot."
        )

    try:
        client_openai = OpenAI(api_key=api_key)

        reponse = client_openai.responses.create(
            model="gpt-5.6-luna",
            tools=[
                {"type": "web_search"}
            ],
            input=(
                "Recherche sur le web les informations demandées ci-dessous. "
                "Donne une réponse claire et concise en français. "
                "Utilise des informations récentes lorsque c'est pertinent. "
                "Indique les sources ou liens utiles dans ta réponse.\n\n"
                f"Recherche : {texte}"
            )
        )

        return reponse.output_text, None

    except Exception as erreur:
        return None, f"❌ Erreur pendant la recherche web : `{erreur}`"



# =========================
# COMMANDES SLASH /
# =========================
#
# Les commandes ! restent disponibles, mais toutes les commandes du bot
# existent aussi avec / pour pouvoir les utiliser depuis le menu Discord.
# Discord, dans sa grande sagesse, aime avoir deux façons de faire la même chose. 🤖

def creer_message_slash(interaction, contenu, mentions=None):
    """Crée un petit objet compatible avec les commandes existantes."""
    class MessageSlash:
        def __init__(self):
            self.author = interaction.user
            self.channel = interaction.channel
            self.guild = interaction.guild
            self.content = contenu
            self.mentions = mentions or []
            self.mention_everyone = False

        async def delete(self):
            return

    return MessageSlash()


async def executer_commande_slash(interaction, contenu, mentions=None):
    """Fait passer une commande slash dans le même système que les commandes !."""
    message = creer_message_slash(interaction, contenu, mentions)

    # Les commandes existantes utilisent channel.send().
    # On répond d'abord à l'interaction pour éviter le timeout Discord.
    try:
        await interaction.response.defer()
    except discord.InteractionResponded:
        pass

    # Petit patch : repondre() doit pouvoir envoyer normalement après le defer.
    await on_message(message)


# ---------- Commandes simples ----------

_COMMANDES_SLASH_SIMPLES = {
    "ping": "Pong ! 🏓",
    "bonjour": "Bonjour ! 👋",
    "salut": "Salut ! 😎",
    "merci": "Avec plaisir ! ❤️",
    "bravo": "Bravo ! 🥳",
    "gg": "GG ! 🎉",
    "lol": "😂😂😂",
    "mdr": "MDR 😂",
    "haha": "HAHA 😂",
    "bonnejournee": "Bonne journée ! ☀️",
    "bonnenuit": "Bonne nuit ! 🌙",
    "courage": "Courage ! 💪",
    "motivation": "On lâche rien ! 🔥",
    "blague": "Pourquoi les plongeurs plongent-ils toujours en arrière ? Parce que sinon ils tombent dans le bateau. 😂",
    "chat": "Miaou ! 🐱",
    "chien": "Wouf ! 🐶",
    "minecraft": "Minecraft ! ⛏️",
    "gaming": "Let's go gaming ! 🎮",
    "coeur": "❤️",
    "triste": "Courage ❤️",
    "roi": "👑 Le roi !",
    "etoile": "⭐",
    "bienvenue": "Bienvenue ! 🎉",
    "respect": "Respect ! 🫡",
    "classe": "La classe ! 😎",
    "wtf": "WTF 💀",
    "ouf": "OUF 😮‍💨",
    "bonappetit": "Bon appétit ! 🍕",
    "bonnechance": "Bonne chance ! 🍀",
    "vache": "Meuh ! 🐮",
    "cochon": "Groin ! 🐷",
    "mouton": "Bêêê ! 🐑",
    "poule": "Cot cot ! 🐔",
    "creeper": "SSSSSSSS... 💚",
    "diamant": "DIAMANT ! 💎",
    "noob": "NOOB 😂",
    "cool": "Trop cool ! 😎",
}

def _creer_callback_simple(nom, reponse):
    async def callback(interaction: discord.Interaction):
        await interaction.response.send_message(reponse)
    callback.__name__ = f"slash_{nom}"
    return callback

for _nom, _reponse in _COMMANDES_SLASH_SIMPLES.items():
    tree.add_command(
        app_commands.Command(
            name=_nom,
            description=f"Commande { _nom } du bot",
            callback=_creer_callback_simple(_nom, _reponse)
        )
    )


# ---------- Aide ----------

@tree.command(name="aide", description="Affiche toutes les commandes du bot")
async def slash_aide(interaction: discord.Interaction):
    texte = (
        "📚 **COMMANDES DU BOT**\n\n"
        "🛠️ **Générales**\n"
        "`/ping` • `/bonjour` • `/salut` • `/merci` • `/bravo` • `/gg`\n"
        "`/lol` • `/mdr` • `/haha` • `/bonnejournee` • `/bonnenuit`\n"
        "`/courage` • `/motivation` • `/blague` • `/bienvenue` • `/respect`\n"
        "`/classe` • `/wtf` • `/ouf` • `/bonappetit` • `/bonnechance`\n\n"
        "🐾 **Animaux / Minecraft**\n"
        "`/chat` • `/chien` • `/vache` • `/cochon` • `/mouton` • `/poule`\n"
        "`/creeper` • `/diamant` • `/minecraft` • `/gaming` • `/noob` • `/cool`\n\n"
        "💬 **Utilitaires**\n"
        "`/message` • `/niveaux` • `/argent` • `/boutique` • `/acheter`\n"
        "`/message` • `/niveaux` • `/timer` • `/quiz` • `/noemoji` • `/rapelle` • `/resetrapelles`\n"
        "`/youtube` • `/resetyoutube` • `/chatgpt` • `/web`\n\n"
        "🎵 **Musique**\n"
        "`/joines` • `/stop`\n\n"
        "🛡️ **Modération**\n"
        "`/resetmessages` • `/confirmerreset` • `/troll` • `/urgence`\n\n"
        "💘 **Fun**\n"
        "`/amourre` • `/debille`\n\n"
        "ℹ️ Les commandes réservées aux administrateurs nécessitent les permissions correspondantes."
    )
    await interaction.response.send_message(texte)



# ---------- Timer / Quiz ----------

def parser_duree_timer(duree: str):
    """Convertit une durée comme 10s, 5m, 1h30m ou 1h en secondes."""
    duree = duree.strip().lower().replace(" ", "")
    if not duree:
        return None

    motifs = re.findall(r"(\d+(?:\.\d+)?)(h|m|s)", duree)
    if not motifs:
        return None

    reconstruit = "".join(nombre + unite for nombre, unite in motifs)
    if reconstruit != duree:
        return None

    total = 0.0
    for nombre, unite in motifs:
        valeur = float(nombre)
        if unite == "h":
            total += valeur * 3600
        elif unite == "m":
            total += valeur * 60
        else:
            total += valeur

    if total <= 0:
        return None
    return total


def formater_duree(secondes: float):
    secondes = int(round(secondes))
    heures, reste = divmod(secondes, 3600)
    minutes, secondes = divmod(reste, 60)

    morceaux = []
    if heures:
        morceaux.append(f"{heures}h")
    if minutes:
        morceaux.append(f"{minutes}min")
    if secondes or not morceaux:
        morceaux.append(f"{secondes}s")
    return " ".join(morceaux)


@tree.command(name="timer", description="Lance un timer avec la durée indiquée")
@app_commands.describe(duree="Durée : 10s, 5m, 1h, ou 1h30m")
async def slash_timer(interaction: discord.Interaction, duree: str):
    secondes = parser_duree_timer(duree)

    if secondes is None:
        await interaction.response.send_message(
            "❌ Durée invalide. Utilise par exemple `/timer 10s`, `/timer 5m`, `/timer 1h` ou `/timer 1h30m`."
        )
        return

    # Discord limite les réponses différées à 15 min, mais le timer peut être plus long.
    await interaction.response.send_message(
        f"⏱️ **Timer lancé !**\nDurée : **{formater_duree(secondes)}**"
    )

    await asyncio.sleep(secondes)

    try:
        await interaction.channel.send(
            f"⏰ **TIMER TERMINÉ !** {interaction.user.mention}\n"
            f"Le timer de **{formater_duree(secondes)}** est terminé ! 🔔"
        )
    except (discord.Forbidden, discord.HTTPException):
        pass


@tree.command(name="quiz", description="Lance un quiz et notifie tout le monde")
@app_commands.describe(question="La question du quiz")
async def slash_quiz(interaction: discord.Interaction, question: str):
    await interaction.response.send_message(
        f"@everyone\n"
        f"🧠 **QUIZ !** 🧠\n\n"
        f"❓ **{question}**\n\n"
        f"💬 Répondez directement dans le salon !"
        ,
        allowed_mentions=discord.AllowedMentions(
            everyone=True,
            users=False,
            roles=False,
            replied_user=False
        )
    )

# ---------- Commandes avec texte ----------

@tree.command(name="message", description="Envoie un message à la place de la commande")
@app_commands.describe(texte="Le texte à envoyer")
async def slash_message(interaction: discord.Interaction, texte: str):
    await interaction.response.send_message(texte)


@tree.command(name="rapelle", description="Ajoute un rappel toutes les minutes")
@app_commands.describe(message="Le texte du rappel")
async def slash_rapelle(interaction: discord.Interaction, message: str):
    # Même comportement que !rapelle, avec une commande slash directe.
    rappels.append({"salon": interaction.channel, "texte": message})
    await interaction.response.send_message(f"🔔 Rappel activé : **{message}**")


@tree.command(name="youtube", description="Abonne ce salon aux vidéos d'une chaîne YouTube")
@app_commands.describe(url_chaine="URL de la chaîne YouTube")
async def slash_youtube(interaction: discord.Interaction, url_chaine: str):
    # Reprend la logique de !youtube en envoyant la commande au gestionnaire.
    await interaction.response.defer()
    fake = creer_message_slash(interaction, f"!youtube {url_chaine}")
    await on_message(fake)


@tree.command(name="web", description="Effectue une recherche web")
@app_commands.describe(recherche="Ce que tu veux rechercher")
async def slash_web(interaction: discord.Interaction, recherche: str):
    await interaction.response.defer()
    resultat, erreur = await asyncio.to_thread(rechercher_web, recherche)
    if erreur:
        await interaction.channel.send(erreur)
        return

    morceaux = [resultat[i:i + 1900] for i in range(0, len(resultat), 1900)] or ["Aucun résultat."]
    await interaction.channel.send(f"🌐 **Résultat de la recherche :**\n{morceaux[0]}")
    for morceau in morceaux[1:]:
        await interaction.channel.send(morceau)


@tree.command(name="chatgpt", description="Pose directement une question à ChatGPT")
@app_commands.describe(question="Ta question")
async def slash_chatgpt(interaction: discord.Interaction, question: str):
    await interaction.response.defer()
    fake = creer_message_slash(interaction, "!chatgpt")
    attentes_chatgpt.discard(interaction.user.id)
    try:
        reponse, erreur = demander_chatgpt(question)
        if erreur:
            await interaction.channel.send(erreur)
        else:
            await interaction.channel.send(f"🤖 {interaction.user.mention}\n{reponse}")
    except Exception as erreur:
        await interaction.channel.send(f"❌ Erreur : `{erreur}`")


# ---------- Niveaux ----------

@tree.command(name="niveaux", description="Affiche ton niveau et ton XP")
async def slash_niveaux(interaction: discord.Interaction):
    utilisateur = str(interaction.user.id)
    if utilisateur not in niveaux:
        niveaux[utilisateur] = {"xp": 0, "niveau": 1}
        sauvegarder_niveaux()

    niveau = niveaux[utilisateur]["niveau"]
    xp = niveaux[utilisateur]["xp"]
    xp_necessaire = xp_pour_niveau(niveau)
    progression = min(xp / max(xp_necessaire, 1), 1) * 100

    await interaction.response.send_message(
        f"⭐ **Tes niveaux**\n\n"
        f"🏆 Niveau : **{niveau}**\n"
        f"✨ XP : **{xp}/{xp_necessaire}**\n"
        f"{barre_xp(xp, xp_necessaire)} **{progression:.0f}%**"
    )


# ---------- Fun avec membres ----------

@tree.command(name="amourre", description="Fait un faux calcul d'amour entre deux membres")
@app_commands.describe(membre1="Premier membre", membre2="Deuxième membre")
async def slash_amourre(interaction: discord.Interaction, membre1: discord.Member, membre2: discord.Member):
    pourcentage = random.randint(0, 100)

    if pourcentage < 20:
        phrase = "💔 Ça sent mal..."
    elif pourcentage < 40:
        phrase = "😬 Il y a peut-être un petit quelque chose..."
    elif pourcentage < 60:
        phrase = "👀 C'est mitigé..."
    elif pourcentage < 80:
        phrase = "💕 Ça commence à devenir sérieux !"
    elif pourcentage < 95:
        phrase = "💖 Très belle compatibilité !"
    else:
        phrase = "💘 L'AMOUR ABSOLU !"

    await interaction.response.send_message(
        f"💘 **CALCULATEUR D'AMOUR** 💘\n\n"
        f"👤 {membre1.mention} ❤️ {membre2.mention}\n\n"
        f"💞 Compatibilité : **{pourcentage}%**\n{phrase}"
    )


@tree.command(name="debille", description="Fait un faux calcul de débilité entre deux membres")
@app_commands.describe(membre1="Premier membre", membre2="Deuxième membre")
async def slash_debille(interaction: discord.Interaction, membre1: discord.Member, membre2: discord.Member):
    p1 = random.randint(0, 100)
    p2 = random.randint(0, 100)

    def phrase_debile(p):
        if p < 20:
            return "🧠 Intelligence en vacances..."
        elif p < 40:
            return "😅 Quelques neurones fonctionnent encore."
        elif p < 60:
            return "🤔 Niveau de débilité modéré."
        elif p < 80:
            return "😂 Ça commence à devenir inquiétant."
        elif p < 95:
            return "🤪 Niveau de débilité élevé !"
        return "💀 LE CERVEAU A QUITTÉ LE SERVEUR !"

    await interaction.response.send_message(
        f"🧠 **CALCULATEUR DE DÉBILITÉ** 🧠\n\n"
        f"👤 {membre1.mention} : **{p1}%**\n{phrase_debile(p1)}\n\n"
        f"👤 {membre2.mention} : **{p2}%**\n{phrase_debile(p2)}"
    )


# ---------- Configuration ----------

@tree.command(name="config", description="Active ou désactive les systèmes du bot")
@app_commands.describe(
    action="Voir, activer ou désactiver un système",
    systeme="Le système à modifier"
)
@app_commands.choices(
    action=[
        app_commands.Choice(name="voir", value="voir"),
        app_commands.Choice(name="activer", value="activer"),
        app_commands.Choice(name="desactiver", value="desactiver"),
    ],
    systeme=[
        app_commands.Choice(name="Anti-spam", value="anti_spam"),
        app_commands.Choice(name="Anti-emoji automatique", value="anti_emoji"),
        app_commands.Choice(name="Blocage @everyone/@here", value="anti_mentions"),
        app_commands.Choice(name="XP / niveaux", value="xp"),
        app_commands.Choice(name="Argent", value="argent"),
        app_commands.Choice(name="Rappels", value="rappels"),
        app_commands.Choice(name="Notifications YouTube", value="youtube"),
        app_commands.Choice(name="Rappel de vérification", value="verification"),
        app_commands.Choice(name="Musique", value="musique"),
    ]
)
async def slash_config(
    interaction: discord.Interaction,
    action: app_commands.Choice[str],
    systeme: app_commands.Choice[str] = None
):
    if interaction.guild is None:
        await interaction.response.send_message("❌ Cette commande doit être utilisée sur un serveur.")
        return

    if not interaction.user.guild_permissions.manage_guild:
        await interaction.response.send_message(
            "❌ Tu dois avoir la permission **Gérer le serveur** pour modifier la configuration."
        )
        return

    config = config_serveur(interaction.guild.id)

    noms = {
        "anti_spam": "🚫 Anti-spam",
        "anti_emoji": "😀 Anti-emoji automatique",
        "anti_mentions": "📣 Blocage @everyone/@here",
        "xp": "⭐ XP / niveaux",
        "argent": "💰 Argent",
        "rappels": "🔔 Rappels",
        "youtube": "📺 Notifications YouTube",
        "verification": "🔎 Rappel de vérification",
        "musique": "🎵 Musique",
    }

    if action.value == "voir":
        lignes = ["⚙️ **CONFIGURATION DU SERVEUR**", ""]
        for cle, nom in noms.items():
            etat = "🟢 ACTIVÉ" if config.get(cle, True) else "🔴 DÉSACTIVÉ"
            lignes.append(f"{nom} : **{etat}**")
        lignes.append("\n💡 Utilise `/config activer` ou `/config desactiver` avec le système voulu.")
        await interaction.response.send_message("\n".join(lignes))
        return

    if systeme is None:
        await interaction.response.send_message(
            "❌ Choisis le système à modifier avec l'option **systeme**."
        )
        return

    cle = systeme.value
    actif = action.value == "activer"
    config[cle] = actif
    sauvegarder_config()

    etat = "activé 🟢" if actif else "désactivé 🔴"
    await interaction.response.send_message(
        f"⚙️ **{noms[cle]}** a été **{etat}** sur ce serveur."
    )


# ---------- Argent / Boutique ----------

@tree.command(name="argent", description="Affiche ton argent")
async def slash_argent(interaction: discord.Interaction):
    solde = solde_utilisateur(interaction.user.id)
    await interaction.response.send_message(
        f"💰 **Ton argent**\n\n🪙 Solde : **{solde} pièces**"
    )


@tree.command(name="boutique", description="Affiche ou gère la boutique")
@app_commands.describe(
    action="Action : voir, ajouter ou supprimer",
    nom="Nom de l'article",
    prix="Prix de l'article",
    image="URL de l'image (facultatif)",
    code="Code à recevoir après l'achat (facultatif)",
    article_id="ID de l'article à supprimer"
)
@app_commands.choices(action=[
    app_commands.Choice(name="voir", value="voir"),
    app_commands.Choice(name="ajouter", value="ajouter"),
    app_commands.Choice(name="supprimer", value="supprimer"),
])
async def slash_boutique(
    interaction: discord.Interaction,
    action: app_commands.Choice[str],
    nom: str = None,
    prix: int = None,
    image: str = None,
    code: str = None,
    article_id: int = None
):
    action = action.value

    if action == "voir":
        if not boutique:
            await interaction.response.send_message(
                "🛒 **Boutique vide !**\nUn modérateur peut ajouter un article avec `/boutique`."
            )
            return

        lignes = ["🛒 **BOUTIQUE DU SERVEUR**", ""]
        for article in boutique:
            ligne = (
                f"🆔 **#{article['id']}** • **{article['nom']}** — "
                f"💰 **{article['prix']} pièces**\n"
                f"🛍️ Pour acheter : `/acheter {article['id']}`"
            )
            if article.get("image"):
                ligne += f"\n🖼️ {article['image']}"
            if article.get("code"):
                ligne += "\n🎁 **Code disponible après achat**"
            lignes.extend([ligne, ""])

        texte = "\n".join(lignes)
        morceaux = [texte[i:i + 1900] for i in range(0, len(texte), 1900)]
        await interaction.response.send_message(morceaux[0])
        for morceau in morceaux[1:]:
            await interaction.followup.send(morceau)
        return

    if not interaction.user.guild_permissions.manage_guild:
        await interaction.response.send_message(
            "❌ Cette action est réservée aux modérateurs ayant la permission **Gérer le serveur**."
        )
        return

    if action == "ajouter":
        if not nom or prix is None:
            await interaction.response.send_message(
                "❌ Indique au minimum un **nom** et un **prix**."
            )
            return

        if prix <= 0:
            await interaction.response.send_message("❌ Le prix doit être supérieur à 0.")
            return

        article = {
            "id": prochain_id_article(),
            "nom": nom[:100],
            "prix": prix,
            "image": image.strip() if image else None,
            "code": code if code else None
        }
        boutique.append(article)
        sauvegarder_boutique()

        await interaction.response.send_message(
            f"✅ **Article ajouté !**\n"
            f"🆔 ID : **#{article['id']}**\n"
            f"📦 Nom : **{article['nom']}**\n"
            f"💰 Prix : **{article['prix']} pièces**"
        )
        return

    if action == "supprimer":
        if article_id is None:
            await interaction.response.send_message("❌ Indique l'ID de l'article.")
            return

        article = next((a for a in boutique if int(a.get("id", 0)) == article_id), None)
        if article is None:
            await interaction.response.send_message("❌ Article introuvable.")
            return

        boutique.remove(article)
        sauvegarder_boutique()
        await interaction.response.send_message(
            f"🗑️ Article **#{article_id} — {article['nom']}** supprimé."
        )


@tree.command(name="acheter", description="Achète un article dans la boutique")
@app_commands.describe(article_id="ID de l'article à acheter")
async def slash_acheter(interaction: discord.Interaction, article_id: int):
    article = next((a for a in boutique if int(a.get("id", 0)) == article_id), None)

    if article is None:
        await interaction.response.send_message(
            "❌ Article introuvable. Utilise `/boutique` pour voir les articles."
        )
        return

    solde = solde_utilisateur(interaction.user.id)
    prix = int(article["prix"])

    if solde < prix:
        await interaction.response.send_message(
            f"❌ Pas assez d'argent. 💰 **{solde}** / 🏷️ **{prix} pièces**"
        )
        return

    argent[str(interaction.user.id)] = solde - prix
    sauvegarder_argent()

    message_achat = (
        f"🎉 **Achat réussi !**\n"
        f"📦 Article : **{article['nom']}**\n"
        f"💰 Prix payé : **{prix} pièces**\n"
        f"💳 Nouveau solde : **{solde - prix} pièces**"
    )

    if article.get("code"):
        message_achat += f"\n\n🔑 **Ton code :** `{article['code']}`"

    if article.get("image"):
        message_achat += f"\n🖼️ {article['image']}"

    await interaction.response.send_message(message_achat)


# ---------- Modération ----------

@tree.command(name="urgence", description="Lance une urgence de modération")
@app_commands.describe(membre="Membre concerné", motif="Motif de l'urgence")
async def slash_urgence(interaction: discord.Interaction, membre: discord.Member, motif: str):
    if interaction.guild is None:
        await interaction.response.send_message("❌ Cette commande doit être utilisée sur un serveur.")
        return

    if not interaction.user.guild_permissions.moderate_members:
        await interaction.response.send_message("❌ Tu n'as pas la permission de gérer les membres.")
        return

    try:
        await membre.timeout(discord.utils.utcnow() + discord.timedelta(minutes=10), reason=motif)
    except Exception:
        # timedelta n'existe pas dans discord.utils sur toutes les versions.
        import datetime
        try:
            await membre.timeout(datetime.timedelta(minutes=10), reason=motif)
        except Exception as erreur:
            await interaction.response.send_message(f"❌ Impossible de mettre {membre.mention} en timeout : `{erreur}`")
            return

    await interaction.response.send_message(
        f"🚨 **URGENCE**\n👤 Membre : {membre.mention}\n📝 Motif : **{motif}**\n⏱️ Timeout : **10 minutes**"
    )


@tree.command(name="noemoji", description="Supprime les messages contenant des emojis du salon")
async def slash_noemoji(interaction: discord.Interaction):
    if not interaction.user.guild_permissions.manage_messages:
        await interaction.response.send_message("❌ Tu n'as pas la permission de gérer les messages.")
        return
    await interaction.response.defer()
    fake = creer_message_slash(interaction, "!noemoji")
    await on_message(fake)


@tree.command(name="resetmessages", description="Demande la suppression des messages du serveur")
async def slash_resetmessages(interaction: discord.Interaction):
    if not interaction.user.guild_permissions.administrator:
        await interaction.response.send_message("❌ Administrateur requis.")
        return
    await interaction.response.send_message(
        "⚠️ Utilise `/confirmerreset` pour confirmer la suppression des messages."
    )


@tree.command(name="confirmerreset", description="Confirme la suppression des messages")
async def slash_confirmerreset(interaction: discord.Interaction):
    if not interaction.user.guild_permissions.administrator:
        await interaction.response.send_message("❌ Administrateur requis.")
        return
    await interaction.response.defer()
    fake = creer_message_slash(interaction, "!confirmerreset")
    await on_message(fake)


@tree.command(name="troll", description="Lance le petit troll de 30 secondes")
async def slash_troll(interaction: discord.Interaction):
    await interaction.response.defer()
    fake = creer_message_slash(interaction, "!troll")
    await on_message(fake)


# ---------- Musique ----------

@tree.command(name="joines", description="Joue une vidéo YouTube dans ton salon vocal")
@app_commands.describe(url="URL YouTube de la musique")
async def slash_joines(interaction: discord.Interaction, url: str):
    if interaction.guild is None:
        await interaction.response.send_message("❌ Cette commande doit être utilisée sur un serveur.")
        return

    if not systeme_actif(interaction.guild, "musique"):
        await interaction.response.send_message("🔴 Le système **musique** est désactivé dans la configuration du serveur.")
        return

    if interaction.user.voice is None or interaction.user.voice.channel is None:
        await interaction.response.send_message("❌ Tu dois être dans un salon vocal.")
        return

    await interaction.response.defer()
    fake = creer_message_slash(interaction, f"!joines")
    attentes_musique[interaction.user.id] = {
        "guild_id": interaction.guild.id,
        "channel_id": interaction.channel.id
    }

    # La logique de !joines attend normalement le prochain message.
    # Ici, on lui donne directement l'URL en lançant la partie de lecture.
    fake = creer_message_slash(interaction, "!joines")
    await jouer_musique(fake, url)


@tree.command(name="stop", description="Arrête la musique")
async def slash_stop(interaction: discord.Interaction):
    await interaction.response.defer()
    fake = creer_message_slash(interaction, "!stop")
    await on_message(fake)


@tree.command(name="resetrapelles", description="Supprime les rappels du salon")
async def slash_resetrapelles(interaction: discord.Interaction):
    if not interaction.user.guild_permissions.administrator:
        await interaction.response.send_message("❌ Administrateur requis.")
        return
    rappels.clear()
    await interaction.response.send_message("🗑️ Tous les rappels ont été supprimés.")


@tree.command(name="resetyoutube", description="Retire l'abonnement YouTube de ce salon")
async def slash_resetyoutube(interaction: discord.Interaction):
    if not interaction.user.guild_permissions.administrator:
        await interaction.response.send_message("❌ Administrateur requis.")
        return

    global youtube_abonnements
    avant = len(youtube_abonnements)
    youtube_abonnements = [
        a for a in youtube_abonnements
        if a.get("channel_id") != interaction.channel.id
    ]
    sauvegarder_youtube()
    await interaction.response.send_message(
        "🗑️ Abonnement YouTube supprimé."
        if len(youtube_abonnements) < avant
        else "ℹ️ Aucun abonnement YouTube trouvé dans ce salon."
    )



# =========================
# TOKEN
# =========================

token = os.getenv("DISCORD_TOKEN")

if token is None:

    raise ValueError(
        "DISCORD_TOKEN environment variable is not set"
    )


# =========================
# LANCEMENT DU BOT
# =========================

client.run(token)